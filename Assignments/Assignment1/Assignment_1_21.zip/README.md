## Group 21 Assignment 1
# Deepak Gangwar (14208)
# Swati Gupta (14644)

* Accuracy was very low for small batch sizes and low learning rate for resnet18
* Even for 100 batch size and learning rate 0.01 it was 40% but for learning rate 0.5 it increases to 80%
* accuracy of VGG16 was around 90% for batch size 10 and learning rate 0.0001 this note book is also attached assignment_1_1_VGG16.ipynb


